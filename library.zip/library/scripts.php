<meta charset="utf-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSS-->
<link rel="stylesheet" type="text/css" href="back/css/main.css">
<!-- Font-icon css-->
<link rel="stylesheet" type="text/css" href="back/font-awesome/css/font-awesome.min.css">
<title>ALU Library App</title>

<script>
  function Clickheretoprint()
    { 
      var disp_setting="toolbar=no,location=no,directories=no,menubar=no,"; 
          disp_setting+="scrollbars=yes,width=2000, height=2000, left=0, top=0"; 
      var content_vlue = document.getElementById("print_content").innerHTML; 

      var docprint=window.open("","",disp_setting); 
       docprint.document.open(); 
       docprint.document.write('<html><head><title>Print</title>');
       docprint.document.write('<link rel="stylesheet" type="text/css" href="css/main.css">');
       docprint.document.write('<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css">');
       docprint.document.write('</head><body onLoad="self.print()" style="padding-left:7%;width:100%; font-size:12px; font-family:calibri;">');          
       docprint.document.write(content_vlue);          
       docprint.document.write('<script src="js/main.js">'); 
       docprint.document.write('</body></html>'); 
       docprint.document.close(); 
       docprint.focus(); 
    }
</script>
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/pace.min.js"></script>
<script src="js/main.js"></script>
<script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">$('#sampleTable').DataTable();</script>
