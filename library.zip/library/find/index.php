<?php $page_id = 'report'; require_once"../db_connection.php"; ?>
<!DOCTYPE html>
<html>
  <body>
    <div class="wrapper">
      <div class="container">
        <div class="row">
          <div class="pull-left col-md-12">
            <br>
            <center><h3>ALU Rwanda Library</h3></center>
            <br><hr>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <table class="table table-hover table-bordered" id="sampleTable">
                  <thead>
                    <tr>
                      <th>Book Name</th>
                      <th>Availability</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $query = mysql_query("SELECT * FROM books") or die(mysql_error());
                      while($get = mysql_fetch_array($query)){
                    ?>
                    <tr>
                      <td><?php echo $get['book_name']; ?></td>
                      <td>
                      <?php
                        echo ($get['status'] == 'Returned' ? 'Available' : 'Not Available');
                      ?>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        </div>
      </div>
    </div>    
    <?php include "scripts.php"; ?>
  </body>
</html>